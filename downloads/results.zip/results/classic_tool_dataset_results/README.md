# Classic Tool Dataset Results

This directory organizes sample-level results for classic and specialized refactoring tools. Each CSV is copied from the corresponding smell delivery dataset, with appended `result_*` columns recording the tool outcome for each sample.

`summary.csv` is aligned with the Classic rows in Table II of the paper. Its fields are:

- `ref_count`: the `#Ref.` value in Table II.
- `reg_percent`: the `Reg. (%)` value in Table II, i.e. the compile/regression-test pass rate.
- `ref_percent`: the `Ref. (%)` value in Table II, i.e. the accepted-refactoring rate.
- `dataset_result_file`: the corresponding sample-level dataset result CSV.

Included tools:

- `JDeodorant/`: `code_clone_type1`, `feature_envy`, `long_method`, `switch_statements`
- `FETruth/`: `feature_envy`
- `EM-Assist/`: `long_method`
- `MM-Assist/`: `feature_envy`
