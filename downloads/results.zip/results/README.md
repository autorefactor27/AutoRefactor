# Results

This directory keeps two dataset-level result folders:

```text
classic_tool_dataset_results/
agent_tool_dataset_results/
human_evaluation_patch_quality/
```

The CSV files in both folders are based on the concrete smell datasets. Result columns are appended after the original sample columns so that tool behavior can be inspected at sample level.

`human_evaluation_patch_quality/` contains the reviewed refactoring patches, sample-level human scores, aggregate summaries, and paper-ready figures for the patch-quality evaluation.

## Aggregated RQ3 table

`rq3_table.csv` is the aggregated performance/cost table for the two agent
systems (AutoRefactor, SWE-agent) across all LLM backbones (one row per smell,
plus a macro `Avg` row). It is derived purely from the per-sample CSVs under
`agent_tool_dataset_results/` and can be regenerated with:

```bash
python3 scripts/generate_rq3_table.py
```

Averaging is **macro** (the `Avg` row is the simple mean of the nine
per-smell means), matching the paper. `Ref%` uses `result_success`, except for
`feature_envy` in `GLM-4.7`, where the CSV carries a project-level test
verdict (`projectfull_run_status`) that is authoritative for that smell.
