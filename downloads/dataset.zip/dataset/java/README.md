# AutoRefactor Java Dataset

This directory contains the Java dataset snapshot used by the AutoRefactor experiments.

## Layout

```text
delivery_schema/   Experiment-ready CSV files used by the paper evaluation
source_tables/     Source table snapshots retained for traceability
manifest.json      Machine-readable dataset inventory
audit.json         Compact row and project-count audit
```

## Delivery Schema

| CSV file | Rows |
| --- | ---: |
| `code_clone_type1.csv` | 31 |
| `data_clumps.csv` | 30 |
| `feature_envy.csv` | 100 |
| `long_method.csv` | 100 |
| `long_parameter_list.csv` | 100 |
| `mysterious_name.csv` | 100 |
| `nested_complexity.csv` | 100 |
| `refused_bequest.csv` | 30 |
| `switch_statements.csv` | 100 |

Total: 691 rows across 12 Java project snapshots.

## Usage

Use `delivery_schema/` as the dataset entry point. If the package has been moved to a new machine, run:

```bash
python3 scripts/prepare_local_dataset.py
```

from the package root to generate localized CSV copies under `work/dataset-local/`.
